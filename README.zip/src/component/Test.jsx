import React, { useState } from 'react';
import marked from 'marked';

function BlogPost() {
  const [markdownContent, setMarkdownContent] = useState('');

  const handleInputChange = (event) => {
    setMarkdownContent(event.target.value);
  }

  return (
    <div>
      <h1>Create a New Blog Post</h1>
      <textarea onChange={handleInputChange} value={markdownContent} />

      <div dangerouslySetInnerHTML={{__html: marked(markdownContent)}}></div>
    </div>
  );
}

export default BlogPost;
